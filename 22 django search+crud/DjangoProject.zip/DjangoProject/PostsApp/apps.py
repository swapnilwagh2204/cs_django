from django.apps import AppConfig


class PostsappConfig(AppConfig):
    name = 'PostsApp'
