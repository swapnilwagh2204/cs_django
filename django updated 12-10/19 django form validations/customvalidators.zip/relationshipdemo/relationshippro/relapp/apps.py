from django.apps import AppConfig


class RelappConfig(AppConfig):
    name = 'relapp'
